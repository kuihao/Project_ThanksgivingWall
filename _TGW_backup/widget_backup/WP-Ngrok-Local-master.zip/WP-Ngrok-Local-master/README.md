ngrok local
==============

Expose your local WordPress to the world

Installation
============
Put this plugin into the wp-content/plugins directory. Activate the plugin when you create the tunnel using ngrok.
